clear all
close all
clc

%%
% Load each file and extract epochs, put in relevant structures
%

% Define the EEG file(s) of interest
fname = {'data_files/c30o30_s4_t1.bdf', 'data_files/c30o30_s4_t2.bdf'};

% Initialise epoch counter
N_epochs = 0;

for fi=1:length(fname)
    % Load the EEG file (fname{fi}). Note the semicolon to surpress echo 
    % of S and HDR to the command window. Don't worry about warnings 
    % concerning overflow detection or the lack of a status channel.
    %
    % For more info type:
    %
    % >> help sload
    %
    [S HDR] = sload(fname{fi});
    
    Fs=512;

% for i=1:17 
% figure 
% plot(S(:,i)) 
% end 

% Implements supplementary_code/part_2/extract_epochs.m 

% Find length of signal 
L = length(S); 
 
% Differentiate trigger channel 
delta_trig = S(2:L,17)-S(1:L-1,17);
  
% Look for rising edges 
trig = find(delta_trig>0); 
 
% Debounce if required 
% I.e. remove spurious short triggers, if any 
%      these can occur when using a manual switch-based trigger 
% e.g. look at the trigger channel in 'data_files/c30o30_s4_t1.bdf' 


T_debounce = 0.5; % (in seconds) - set as desired 
dt_trig = trig(2:end) - trig(1:end-1); 
delete_short_trigs = find(dt_trig < Fs*T_debounce) + 1; 
trig(delete_short_trigs) = []; 
  
% How many triggers were extracted in total, after debouncing? 
N_trigs = length(trig)-1; 
  
% Ensure we have an odd number of triggers (ignore final incomplete  
% epoch if not). 
% Trigger 1 = start of experiment 
% Triggers 2, 4, 6, 8... (2k) = eyes closed 
% Triggers 3, 5, 7, 9... (2k+1) = eyes open 
if mod(N_trigs, 2) == 0 
    N_trigs = N_trigs - 1; 
end     
  
disp(cell2mat(strcat({'Found '}, int2str(N_trigs), {' triggers.'}))); 
     
N_epochs = N_trigs; 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Extract triggers
    
    % throw an error % insert your own code here to extract the triggers 
                   % (see previous part of the lab)
    

    % Discard 2 seconds of data before & after each cue
    discard = 2*Fs;

    % Extract each epoch of data and store in the relevant structure for 
    % each class
    % - ec: Eyes closed
    % - eo: Eyes open
    this_epochs = 0;
    Epoch_length = 24; % in seconds
    samples = Epoch_length*Fs;
    for i=1:N_trigs/2
        ec_extracted{i} = S(trig(2*i)+discard:trig(2*i+1)-discard,1:16);
        eo_extracted{i} = S(trig(2*i+1)+discard:trig(2*i+2)-discard,1:16);
        maxlen = min(length(ec_extracted{i}), length(eo_extracted{i}));
        N_loop = floor(maxlen / samples);
        for j = 1:N_loop
            N_epochs = N_epochs + 1;
            this_epochs = this_epochs + 1;
            ec{N_epochs} = ec_extracted{i}((j-1)*samples+1:j*samples,:);
            eo{N_epochs} = eo_extracted{i}((j-1)*samples+1:j*samples,:);

        end
    end
    disp(cell2mat(strcat({'Extracted '}, int2str(this_epochs), {', '},...
        int2str(Epoch_length), {' second epochs of each class from '})));
end
disp(cell2mat(strcat({'Extracted a total of '}, int2str(N_epochs),...
    {', '}, int2str(Epoch_length), {' second epochs of each class.'})));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Plot FFT of raw data eo = eyes open 
eo_fft = fft(eo{N_epochs});
ec_fft = fft(ec{N_epochs});

% Specify the electrode montage on scalp (the electrode numbers laid out  
% in a matrix, according to their positions on the scalp and as we want  
% them to be displayed 
montage = [-1 -1 1 -1 -1; 2 3 4 5 6; 7 8 9 10 11; 12 13 14 15 16]; 
  
% The 10/20 labels for each electrode channel (again, corresponding to the  
% montage above. In this case electrode 1 = Fz, electrode 2 = FC3,  
% electrode 3 = FC1 etc. 
electrode_labels = {'Fz', 'FC3', 'FC1', 'FCz', 'FC2', 'FC4','C3', 'C1', 'Cz', 'C2', 'C4','CP3', 'CP1', 'CPz', 'CP2', 'CP4'}; 
% Create a new figure (or select an existing one if you prefer) 
figure
for j=1:4 
    for i=1:5 
        % Only create plots for electrodes that exist (ignore -1 values) 
        if montage(j, i) > 0 
            % which electrode is at this location in the montage matrix? 
            electrode = montage(j, i); 
            % select the correct (row, colum) --> what does the number 5 do 
            % here? 
            subplot(4, 5, i+(5*(j-1))) 
             
            % plot something for the current electrode. You can plot 
            % whatever data you want here, but for example: 
            plotFFT2(eo_fft(:,electrode), Fs)
            plotFFT2(ec_fft(:,electrode), Fs)

            % Set axes limits if necessary, e.g. 
            ylim([0 4000]) 
            xlim([0 200]) 
             
            % Label each subplot with the corresponding electrode poistion 
            title(electrode_labels{electrode}) 
             
            % Label the axes for the bottom left plot only (to prevent the 
            % figure getting too crowded and illegible) 
            if i == 1 && j == 4 
                xlabel('Frequency (Hz)'); 
                ylabel('FFT (V)') 
            end
        end
    end
end

% Implements supplementary_code/part_3/calc_psd.m 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Pre-filter data and calculate PSD for every epoch and every electrode.  
% The PSD should be resampled into 2Hz �bins� 

% Band pass 2-40 Hz (use the filter you designed earlier) 
b_bp = band_pass(Fs); 
  
% Iterate through every extracted epoch 
for i = 1:N_epochs 
     
    % Iterate through each electrode channel (Ei) 
    for Ei = 1:16 
         
        % Apply bandpass filter to eyes open 
        eo_bp(:,:,Ei) = filter(b_bp, 1, eo{N_epochs}(:,Ei)); 
         
        %??? NOW FILTER EYES CLOSED ???%  
        ec_bp(:,:,Ei) = filter(b_bp, 1, ec{N_epochs}(:,Ei)); 
  
        % Calculate PSD for Ei using the Welch method 
        [psd freqs] = pwelch(eo_bp(:,:,Ei), [], [], [], Fs); 
        N_psd = length(psd) - 1; 
        temp_psd = reshape(psd(1:N_psd), N_psd/(Fs / (2 * 2)), []); 
        eo_psd_2hz(:,i,Ei) = mean(temp_psd,1);
       
        
        [psd freqs] = pwelch(ec_bp(:,:,Ei), [], [], [], Fs); 
        N_psd = length(psd) - 1; 
        temp_psd = reshape(psd(1:N_psd), N_psd/(Fs / (2 * 2)), []); 
        ec_psd_2hz(:,i,Ei) = mean(temp_psd,1);

    end 
end

disp('calculate PSDs of all epoch')

%eo_psd_2hz_zero = zeros(128,16);
%ec_psd_2hz_zero = zeros(128,16);

% Iterate through every extracted epoch 
for i = 1:N_epochs 
     
    % Iterate through each electrode channel (Ei) 
    for Ei = 1:16 
        % Calculate mean and standard deviation
       % eo_psd_2hz_psd(:,Ei) = eo_psd_2hz(:,Ei).^2
        eo_psd_2hz_mean(:,Ei) = mean(eo_psd_2hz(:,:,Ei),2)
        eo_psd_2hz_std(:,Ei) = std(eo_psd_2hz(:,i,Ei))
        
        ec_psd_2hz_mean(:,Ei) = mean(ec_psd_2hz(:,:,Ei),2)
        ec_psd_2hz_std(:,Ei) = std(ec_psd_2hz(:,i,Ei))
    end
end

% Plot discriminant power matrix 6-40Hz by 16 electrodes

discmatrix = abs (eo_psd_2hz_mean(3:21,:) - ec_psd_2hz_mean(3:21,:))
figure
imagesc([5 41], [1 16], discmatrix')
xlabel('Frequency bins [f-1,f+1) (Hz)')
ylabel('Channel number')
title('Discriminant power (feature matrix)')
clh = colorbar;
ylabel(clh, 'PSD (V^2/Hz)')
set(gca, 'XTick', [5:2:39])
xlim([4 40])
set(gca, 'YTick', [1:16])

% Plot PSDs for Eyes Open (eo) and Eyes Closed (ec) 
%plot(eo_psd_2hz(:,i,Ei))
%plot(ec_psd_2hz(:,i,Ei))

% set up frequency axis
figure
xf_temp = reshape(freqs(1:N_psd), N_psd/(Fs / (2 * 2)), []) - 1;
xf = xf_temp(1,:);

Ei = 4;

% plot mean and std dev  
%h = superbar(xf, eo_psd_2hz_mean(:,Ei), 'E', ec_psd_2hz_mean(:,Ei));
h = superbar(xf, [eo_psd_2hz_mean(:,Ei) ec_psd_2hz_mean(:,Ei)], 'E', [eo_psd_2hz_std(:,Ei) ec_psd_2hz_std(:,Ei)]);

% Colour the groups and add legend (avoiding bug in superbar grouping)
Colours = [.8 .2 .2;
     .2 .8 .2];
for iBarSeries = 1:length(eo_psd_2hz_mean)
    set(h(iBarSeries, 1), 'FaceColor', Colours(1, :), 'EdgeColor', 'none');
    set(h(iBarSeries, 2), 'FaceColor', Colours(2, :), 'EdgeColor', 'none');
end
legend([h(1,1) h(1,2)], 'Eyes Open', 'Eyes Closed');

% Add labels and set axes limits
str_title = cell2mat(strcat({'PSD in 2Hz bins for '}, electrode_labels{Ei}));
title(str_title)
xlim([0,40])
set(gca, 'XTick', 1:2:39)
% ylim([0, 75])
ylabel('PSD (V^2/Hz)')
xlabel('Frequency bins [f-1, f+1)  (Hz)')

% Plot Discriminant Power for Eyes Open (eo) and Eyes Closed (ec)

% set up frequency axis
figure
xf_temp = reshape(freqs(1:N_psd), N_psd/(Fs / (2 * 2)), []) - 1;
xf = xf_temp(1,:);

Ei = 4;

% plot discriminant power  
%h = superbar(xf, eo_psd_2hz_mean(:,Ei), 'E', ec_psd_2hz_mean(:,Ei));
disc_2hz(Ei,:)= abs (eo_psd_2hz_(3:21,:) - ec_psd_2hz_mean(3:21,:))
h = superbar(xf, [eo_psd_2hz_mean(:,Ei) ec_psd_2hz_mean(:,Ei)], 'E', [eo_psd_2hz_std(:,Ei) ec_psd_2hz_std(:,Ei)]);

% Colour the groups and add legend (avoiding bug in superbar grouping)
Colours = [.8 .2 .2;
     .2 .8 .2];
for iBarSeries = 1:length(eo_psd_2hz_mean)
    set(h(iBarSeries, 1), 'FaceColor', Colours(1, :), 'EdgeColor', 'none');
    set(h(iBarSeries, 2), 'FaceColor', Colours(2, :), 'EdgeColor', 'none');
end
legend([h(1,1) h(1,2)], 'Eyes Open', 'Eyes Closed');

% Add labels and set axes limits
str_title = cell2mat(strcat({'PSD in 2Hz bins for '}, electrode_labels{Ei}));
title(str_title)
xlim([0,40])
set(gca, 'XTick', 1:2:39)
% ylim([0, 75])
ylabel('PSD (V^2/Hz)')
xlabel('Frequency bins [f-1, f+1)  (Hz)')
