function plot_DPM(eo_psd_2hz_mean, ec_psd_2hz_mean)
% Plot discriminant power matrix 6-40Hz by 16 electrodes
discmatrix = abs(eo_psd_2hz_mean(3:21,:) - ec_psd_2hz_mean(3:21,:))
figure
imagesc([5 41], [1 16], discmatrix')
xlabel('Frequency bins [f-1,f+1) (Hz)')
ylabel('Channel number')
title('Discriminant power (feature matrix)')
clh = colorbar;
ylabel(clh, 'PSD (V^2/Hz)')
set(gca, 'XTick',[5:2:39]) % what shoudl go here ?
xlim([4 40])
ylim([1 16])
set(gca, 'YTick', [1:1:16])
end

