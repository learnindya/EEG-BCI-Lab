clear all
close all
clc

[S41 HDRS41] = sload('c30o30_s4_t1.bdf');

Fs = HDRS41.SampleRate;

% length of signals
L41 = length(S41);

% Differeintiate trigger channel
delta_trig41 = S41(2:L41,17) - S41(1:L41-1,17);

% Look for rising edges
trig41 = find(delta_trig41>0);

% Debounce if required
% I.e. remove spurious short triggers, if any
% these can occur when using a manual switch-based trigger
% e.g. look at the trigger channel in 'data_files/c30o30_s4_t1.bdf'
T_debounce41 = 0.5; % (in seconds) - set as desired
dt_trig41 = trig41(2:end) - trig41(1:end-1);
delete_short_trigs41 = find(dt_trig41 < Fs*T_debounce41) + 1;
trig41(delete_short_trigs41) = [];

% How many triggers were extracted in total after debouncing?
N_trigs41 = length(trig41)-1;

% Ensure we have an odd number of triggers (ignore final incomplete
% epoch if not).
% Trigger 1 = start of experiment
% Triggers 2, 4, 6, 8... (2k) = eyes closed
% Triggers 3, 5, 7, 9... (2k+1) = eyes open
if mod(N_trigs41, 2) == 0
N_trigs41 = N_trigs41 - 1;
end

% write on command window
disp(cell2mat(strcat({'Found '}, int2str(N_trigs41), {' triggers.'})));

N_epochs41 = N_trigs41;
% Discard 2 seconds of data before & after each cue
discard = 2*Fs;

% Extract each epoch of data and store in the relevant structure for
% each class
% - eyes_closed (even triggers)
% - eyes_open (odd triggers)
for i=1:N_epochs41/2
eyes_closed41{i} = S41(trig41(2*i)+discard:trig41(2*i+1)-discard,1:16);
eyes_open41{i} = S41(trig41(2*i+1)+discard:trig41(2*i+2)-discard,1:16);
end

FFT41 = ssfft2(eyes_closed41{1},Fs/2);

eo_fft = FFT41;

