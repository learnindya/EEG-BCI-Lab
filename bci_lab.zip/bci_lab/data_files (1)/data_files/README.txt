Description of data:

% Fake signals
%
% 	Toy data to get you started

% BDF files real data
%
% 	file prefixes: c30o30
% 		Trigger 1 = start of experiment
% 		Triggers 2, 4, 6, 8... (2k) = eyes closed
% 		Triggers 3, 5, 7, 9... (2k+1) = eyes open
% 	file suffixes
%		s = subject (participant) number
%		t = trial (session) number
%
% 		i.e. all recordings with s4 come from the same subject (participant)


% Bad data
%
% 	Folder including more BDF recordings made in class,
%	where the signals do not seem to be good enough quality 
%	to use in the lab session. Included for reference only 