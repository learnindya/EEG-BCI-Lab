function y = low_pass(Fs)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% High pass filter design
% Filter order (number of coefficients to generate)
N_filt = 512;

% Nyquist frequency
Nyq = Fs / 2;

% Filter frequency breakpoints (2-2.1Hz imperfect, but necessary to
% find a solution).
f_filt = [ 0 40/Nyq 40.1/Nyq 1];

% Filter magnitude breakpoints
m_filt = [ 1 1 0 0];
b_k = fir2(N_filt, f_filt, m_filt);
% Plot the filter kernel (b_k co-efficients)

figure(6)
nf = 1:N_filt;
plot(b_k)
ylabel('b_k')
xlabel('Filter taps (k)')
title('High Pass Filter Design')
% Plot the frequency response of the filter
figure(7)
freqz(b_k)
y = b_k;


end

