clear all
close all
clc

load('fake_signals.mat');

N = length(X1);

t = (1:N) / Fs;

% fft
n = 2^nextpow2(N);
FFT1 = fft(X1,n);
L = length(FFT1);
FFT2 = fft(X2,n);

% power
P2 = abs(FFT1/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);

P22 = abs(FFT2/L);
P11 = P22(1:L/2+1);
P11(2:end-1) = 2*P11(2:end-1);

PSD1 = P1.^2;
PSD2 = P11.^2;

f = Fs*(0:(L/2))/L;

% plot discriminant
discr = abs(PSD1 - PSD2);


%% High pass filter design
 b = high_pass(Fs)
 a = 1;
 
 x1filt = filter(b,a,X1)
 
 X1filt = fft(x1filt,n);
 
 P2filt = abs(X1filt/L);
 P1filt = P2filt(1:L/2+1);
 P1filt(2:end-1) = 2*P1filt(2:end-1);
 
 %% Low pass filter design
 b2 = low_pass(Fs);
 
 x1LP = filter(b2,a,x1filt);
 
 X1LP = fft(x1LP,n);
 
 P2LP = abs(X1LP/L);
 P1LP = P2LP(1:L/2+1);
 P1LP(2:end-1) = 2*P1LP(2:end-1);
 
 %% Bandpass filter design
 b3 = bandpass(Fs);
 
 x1BP = filter(b3,a,X1)
 
 X1BP = fft(x1BP,n);
 
 P2BP = abs(X1BP/L);
 P1BP = P2BP(1:L/2+1);
 P1BP(2:end-1) = 2*P1BP(2:end-1);
 
 
 


%% plots
figure(1)
subplot(3,2,1)
plot(t,X1);
hold on
xlabel('time in [t]')
ylabel('X1 in [V]')
grid
subplot(3,2,3)
plot(f,P1)
xlim([-10 256])
subplot(3,2,5)
plot(f,PSD1)

subplot(3,2,2)
plot(t,X2);
hold on
xlabel('time in [t]')
ylabel('X1 in [V]')
grid
subplot(3,2,4)
plot(f,P11)
xlim([-10 256])
subplot(3,2,6)
plot(f,PSD2)

figure(2)
plot(f,discr)

figure(5)
subplot(4,1,1)
plot(t,x1filt)
subplot(4,1,2)
plot(f,P1filt)
subplot(4,1,3)
plot(f,P1LP)
subplot(4,1,4)
plot(f,P1BP)





