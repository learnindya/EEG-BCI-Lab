function [eo_psd_2hz, ec_psd_2hz,eo_psd_2hz_mean, eo_psd_2hz_std, ec_psd_2hz_mean, ec_psd_2hz_std, dp_2hz,dp_2hz_mean,dp_2hz_std, N_psd, freqs] = calc_psd(eo, ec, Fs, N_epochs)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pre-filter data and calculate PSD for every epoch and every electrode. 
% The PSD should be resampled into 2Hz ?bins?
 
% Band pass 2-40 Hz (use the filter you designed earlier)
b_bp = bandpass(Fs);

eo_psd_2hz_mean = zeros(128,16);
ec_psd_2hz_mean = zeros(128,16);
eo_psd_2hz_std = zeros(128,16);
ec_psd_2hz_std = zeros(128,16);

dp_2hz = zeros(128,19,16);
dp_2hz_mean = zeros(128,16);
dp_2hz_std = zeros(128,16);
 
% Iterate through every extracted epoch
for i = 1:N_epochs
    
    % Iterate through each electrode channel (Ei)
    for Ei = 1:16
        
        % Apply bandpass filter to eyes open
        eo_bp(:,:,Ei) = filter(b_bp, 1, eo{i}(:,Ei));
        
        %??? NOW FILTER EYES CLOSED ???% 
        ec_bp(:,:,Ei) = filter(b_bp, 1, ec{i}(:,Ei)); 
 
        % Calculate PSD for Ei using the Welch method
        [psd freqs] = pwelch(eo_bp(:,:,Ei), [], [], [], Fs);
        N_psd = length(psd) - 1;
        temp_psd = reshape(psd(1:N_psd), N_psd/(Fs / (2 * 2)), []);
        eo_psd_2hz(:,i,Ei) = mean(temp_psd,1);
        eo_psd_2hz_mean(:,Ei) = eo_psd_2hz_mean(:,Ei) + eo_psd_2hz(:,i,Ei)*(1/19);
        eo_psd_2hz_std(:,Ei) = eo_psd_2hz_std(:,Ei) + (abs(eo_psd_2hz_mean(:,Ei)- eo_psd_2hz(:,i,Ei)))*(1/19);
        
        %??? NOW calculate PSD EYES CLOSED ???%
        [psd freqs] = pwelch(ec_bp(:,:,Ei), [], [], [], Fs);
        N_psd = length(psd) - 1;
        temp_psd = reshape(psd(1:N_psd), N_psd/(Fs / (2 * 2)), []);
        ec_psd_2hz(:,i,Ei) = mean(temp_psd,1);
        ec_psd_2hz_mean(:,Ei) = ec_psd_2hz_mean(:,Ei) + ec_psd_2hz(:,i,Ei)*(1/19);
        ec_psd_2hz_std(:,Ei) = ec_psd_2hz_std(:,Ei) + (abs(ec_psd_2hz_mean(:,Ei)- ec_psd_2hz(:,i,Ei)))*(1/19);

        %DP
        dp_2hz(:,i,Ei) = abs(eo_psd_2hz(:,i,Ei) - ec_psd_2hz(:,i,Ei));
        dp_2hz_mean(:,Ei) = dp_2hz_mean(:,Ei) + dp_2hz(:,i,Ei)*(1/19);
        dp_2hz_std(:,Ei) = dp_2hz_std(:,Ei) + (abs(dp_2hz_mean(:,Ei)- dp_2hz(:,i,Ei)))*(1/19);
        
    end
end

end

