clear all
close all
clc

% Define the EEG file(s) of interest
fname = {'c30o30_s4_t1.bdf', 'c30o30_s4_t2.bdf','c30o30_s5_t1.bdf','c30o30_s5_t2.bdf'};

% extracting the epochs and relevant information
[ec, eo,Fs, N_epochs] = extract_epochs(fname);

% calculate the fft, P and PSD of 1 individual epoch
[ec_fft,P, PSD] = ssfft2(ec{1},Fs);

% calculate the PSD using a BP filter (2-40hz) and welch method
[eo_psd_2hz, ec_psd_2hz, eo_psd_mean, eo_psd_std, ec_psd_mean, ec_psd_std,dp_2hz,dp_2hz_mean,dp_2hz_std, N_psd, freqs] = calc_psd(eo, ec,Fs, N_epochs);

% PLots
plotting_FFT(ec_fft,Fs);
%plotting_P_PSD(P,Fs);
%plotting_P_PSD(PSD,Fs);
%plotting_P_PSD(ec_psd_2hz,Fs);
%plotting_P_PSD(eo_psd_2hz,Fs);
plot_DPM(eo_psd_mean,ec_psd_mean);
plot_PSD(eo_psd_mean, ec_psd_mean, eo_psd_std, ec_psd_std, N_psd,Fs, freqs,1);
%plot_D(dp_2hz_mean, dp_2hz_std, N_psd,Fs, freqs,1);


disc_power_mean = abs(mean(ec_psd_2hz(:,:,4)-eo_psd_2hz(:,:,4),2));
disc_power_std = std((ec_psd_2hz(:,:,4) - eo_psd_2hz(:,:,4))')';

plot_D(disc_power_mean, disc_power_std, N_psd,Fs, freqs,1);

eo_features(:,1:5) = eo_psd_2hz(7:11,:,4)';
ec_features(:,1:5) = ec_psd_2hz(7:11,:,4)';

features = [eo_features; ec_features];
for i=1:N_epochs
    my_classes{i} = 'eyes open';
    my_classes{i+N_epochs} = 'eyes closed';
end
classes = my_classes';

figure(10)
gscatter(features(:,1), features(:,2), classes,'rb','od');
xlabel('8-10Hz power Ei (V^2/Hz)');
ylabel('10-12Hz power Ei (V^2/Hz)');

%linear discriminant analysis (LDA).
lda = fitcdiscr(features(:,1:2),classes)
ldaClass = resubPredict(lda)
ldaResubErr = resubLoss(lda)
[ldaResubCM,grpOrder] = confusionmat(classes,ldaClass)

bad = ~strcmp(ldaClass,classes);
hold on;
plot(features(bad,1), features(bad,2), 'kx');
hold off;

% K-Fold cross validation for LDA
cp = cvpartition(classes,'KFold',5)
cvlda = crossval(lda,'CVPartition',cp);
ldaCVErr = kfoldLoss(cvlda)


% obtain the ROC by cross-validation:
[LDALabel, LDAScore] = kfoldPredict(cvlda);
[FPR, TPR, Thr, AUC, OPTROCPT] = perfcurve(classes, LDAScore(:,1), 'eyes closed');
figure(12)
plot(FPR, TPR, 'r', 'linewidth', 3)
hold on
plot ([0 1], [0 1], '--k')
xlabel('False positive rate (1 - Specificity)')
ylabel('True positive rate (Sensitivity)')
title('ROC for Classification by LDA')
legend('LDA', 'Chance')



