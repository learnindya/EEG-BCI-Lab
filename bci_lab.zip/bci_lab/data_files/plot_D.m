function plot_D(eo_psd_2hz_mean, eo_psd_2hz_std, N_psd,Fs, freqs,Ei)

% Plot PSDs for Eyes Open (eo) and Eyes Closed (ec) 
figure
% set up frequency axis
xf_temp = reshape(freqs(1:N_psd), N_psd/(Fs / (2 * 2)), []) - 1;
xf = xf_temp(1,:);

electrode_labels = {'Fz', 'FC3', 'FC1', 'FCz', 'FC2', 'FC4','C3', 'C1',... 
                       'Cz', 'C2', 'C4','CP3', 'CP1', 'CPz', 'CP2', 'CP4'};

%Ei = 1;% Choose your electrode here!

% plot mean and std dev  
h = superbar(xf, [eo_psd_2hz_mean(:,Ei)], 'E', [eo_psd_2hz_std(:,Ei)]);

% Colour the groups and add legend (avoiding bug in superbar grouping)
Colours = [.8 .2 .2];
 for iBarSeries = 1:length(eo_psd_2hz_mean)
    set(h(iBarSeries, 1), 'FaceColor', Colours(1, :), 'EdgeColor', 'none');
end
%legend([h(1,1)], 'Eyes Open', 'Eyes Closed');

% Add labels and set axes limits
str_title = cell2mat(strcat({'PSD in 2Hz bins for '}, electrode_labels{Ei}));
title(str_title)
xlim([0,40])
set(gca, 'XTick', 1:2:39)
% ylim([0, 75])
ylabel('PSD (V^2/Hz)')
xlabel('Frequency bins [f-1, f+1)  (Hz)')

end



