function P1 = ssfft(X)
%
% function P1 = ssfft(X)
%
%   computes the one-sided amplitude spectrum of the fft(X) 
%   for more info type 
%   >> doc fft
%

L = length(X);

n = 2^nextpow2(L);

Y = fft(X, n);

dim = size(Y);
if (dim(1) == 1)
    % standard approach for a vector
    P2 = abs(Y/n);
    P1 = P2(1:n/2+1);
    P1(2:end-1) = 2*P1(2:end-1);
else
    % work for a matrix
    P2 = abs(Y/n);
    P1 = P2(1:n/2+1,:);
    P1(2:end-1,:) = 2*P1(2:end-1,:);
end    