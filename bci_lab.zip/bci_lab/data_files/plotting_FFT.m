function plotting_FFT(eo_fft,Fs)
% Specify the electrode montage on scalp (the electrode numbers laid out 
% in a matrix, according to their positions on the scalp and as we want 
% them to be displayed
montage = [-1 -1 1 -1 -1; 2 3 4 5 6; 7 8 9 10 11; 12 13 14 15 16];

% The 10/20 labels for each electrode channel (again, corresponding to the 
% montage above. In thsi case electrode 1 = Fz, electrode 2 = FC3, 
% electrode 3 = FC1 etc.
electrode_labels = {'Fz', 'FC3', 'FC1', 'FCz', 'FC2', 'FC4','C3', 'C1',... 
                       'Cz', 'C2', 'C4','CP3', 'CP1', 'CPz', 'CP2', 'CP4'};

% Create a new figure (or select an exisiting one if you prefer)
figure

% Iterate through each row (j) and column(i) of the montage matrix that
% will form your subplot figure
for j=1:4
    for i=1:5
        % Only create plots for electrodes that exist (ignore -1 values)
        if montage(j, i) > 0
            % which electrode is at this location in the montage matrix?
            electrode = montage(j, i);
            % select the correct (row, colum) --> what does the number 5 do
            % here?
            subplot(4, 5, i+(5*(j-1)))
            
            % plot something for the current electrode. You can plot
            % whatever data you want here, but for example:
            plotFFT2(eo_fft(:,electrode), Fs)
            
            % Set axes limits if necessary, e.g.
            ylim([0 25000])
            xlim([0 40])
            
            % Label each subplot with the corresponding electrode poistion
            title(electrode_labels{electrode})
            
            % Label the axes for the bottom left plot only (to prevent the
            % figure getting too crowded and illegible)
            if i == 1 && j == 4
                xlabel('Frequency (Hz)');
                ylabel('FFT (V)')
            end
        end
    end
end

% Add a title to the entire plot - play around, as required
annotation('textbox', [0.1,0.75, 0.2, 0.2], 'String', 'eyes closed',...
                                'FontWeight', 'bold', 'LineStyle', 'none')
