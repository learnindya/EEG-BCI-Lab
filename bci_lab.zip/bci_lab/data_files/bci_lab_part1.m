% raw signal X1 in time domain
load('fake_signals.mat'); 
figure(1)
N = length(X1);
t = (1:N) / Fs;
subplot(3,1,1);
plot(t,X1);
ylabel('X1(V)', 'FontSize', 16)
xlabel('Time(s)', 'FontSize', 16)
title('Raw Signal')

% X1 in frequency domain
X_fft = ssfft(X1);
N_fft = length(X1) / 2;
f_fft = (0:N_fft)*Fs / (2*N_fft);
figure(1)
subplot(3,1,2);
plot(f_fft,X_fft);
ylabel('||FFT(X1)||(V)', 'FontSize', 16)
xlabel('Frequency (Hz)', 'FontSize', 16)

% X1 in power spectral density
FFt1 = fft(X1);
N_fft = length(X1)/2;
f_fft = (1:N_fft)*Fs/(2*N_fft);
Xk = abs(FFt1(1:floor(N_fft)));
psd1 = Xk.^2;
subplot(3,1,3);
plot(f_fft,psd1);
ylabel('PSD(X1)(V)', 'FontSize', 16)
xlabel('Frequency (Hz)', 'FontSize', 16)

% raw signal X2 in time domain
figure(2)
N = length(X2);
t = (1:N) / Fs;
subplot(3,1,1);
plot(t,X2);
ylabel('X2(V)', 'FontSize', 16)
xlabel('Time(s)', 'FontSize', 16)

% X2 in frequency domain
X_fft = ssfft(X2);
N_fft = length(X2) / 2;
f_fft = (0:N_fft)*Fs / (2*N_fft);
figure(2)
subplot(3,1,2);
plot(f_fft,X_fft);
ylabel('||FFT(X2)||(V)', 'FontSize', 16)
xlabel('Frequency (Hz)', 'FontSize', 16)

% X3 in power spectral density
FFt1 = fft(X2);
N_fft = length(X2)/2;
f_fft = (1:N_fft)*Fs/(2*N_fft);
Xk = abs(FFt1(1:floor(N_fft)));
psd2 = Xk.^2;
figure(2)
subplot(3,1,3);
plot(f_fft,psd2);
ylabel('PSD(X2)(V)', 'FontSize', 16)
xlabel('Frequency (Hz)', 'FontSize', 16)

% discriminant power
figure(3)
D = abs(psd1-psd2);
plot(D);
xlabel('Discriminant power', 'FontSize', 16)

% raw signal X1
N = length(X1);
t = (1:N) / Fs;
figure(4)
subplot(4,1,1);
plot(t,X1);
ylabel('X1(V)', 'FontSize', 16)
xlabel('Time(s)', 'FontSize', 16)

% X1 filtered at 2 Hz (high pass filter)
a = 1;
b = high_pass(Fs);
x1filtered = filter(b,a,X1);
figure(4)
subplot(4,1,2);
plot(t,x1filtered);
ylabel('X1(V)', 'FontSize', 16)
xlabel('Time(s)', 'FontSize', 16)

% X1 filtered at 40 Hz (low pass filter)
a = 1;
b = low_pass(Fs);
x1filtered_low = filter(b,a,X1);
figure(4)
subplot(4,1,3);
plot(t,x1filtered_low);
ylabel('X1(V)', 'FontSize', 16)
xlabel('Time(s)', 'FontSize', 16)

% X1 in frequency domain
FFt1 = fft(X1);
N_fft = length(X1)/2;
f_fft = (1:N_fft)*Fs/(2*N_fft);
Xk = abs(FFt1(1:floor(N_fft)));
psd1 = Xk.^2;
figure(5)
subplot(3,1,1);
plot(f_fft,psd1);
ylabel('||FFT(X1)||(V)', 'FontSize', 16)
xlabel('Frequency (Hz)', 'FontSize', 16)

FFt1 = fft(x1filtered);
N_fft = length(X1)/2;
f_fft = (1:N_fft)*Fs/(2*N_fft);
Xk = abs(FFt1(1:floor(N_fft)));
psd1 = Xk.^2;
figure(5)
subplot(3,1,2);
plot(f_fft,psd1);
ylabel('||FFT(X1)||(V)', 'FontSize', 16)
xlabel('Frequency (Hz)', 'FontSize', 16)

%filtered @40Hz
FFt1 = fft(x1filtered);
N_fft = length(X1)/2;
f_fft = (1:N_fft)*Fs/(2*N_fft);
Xk = abs(FFt1(1:floor(N_fft)));
psd1 = Xk.^2;
figure(5)
subplot(3,1,3);
plot(f_fft,psd1);
ylabel('||FFT(X1)||(V)', 'FontSize', 16)
xlabel('Frequency (Hz)', 'FontSize', 16)