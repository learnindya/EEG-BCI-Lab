clear all
close all
clc

load('fake_signals.mat');

figure(1)
N = length(X1);
t = (1:N) / Fs; %time=4096/512
plot (t,X1);
title 'X1 graph'

figure(2)
N = length(X2);
t = (1:N) / Fs;
plot (t,X2);
title 'X2 graph'

FFT1 = fft(X1)
N_FFT = length(X1)/2; %length
f_FFT = (1:N_FFT) * Fs / (2* N_FFT); %sampling frequency
Xk = abs(FFT1(1:floor(N_FFT)));
figure(3)
subplot(3,1,1)
plot(t,X1)
subplot(3,1,2)
plot(f_FFT,Xk)
title 'X1 2 graphs'


FFT1 = fft(X2)
N_FFT = length(X2)/2;
f_FFT = (1:N_FFT) * Fs / (2* N_FFT);
Xk = abs(FFT1(1:floor(N_FFT)));
figure(4)
subplot(3,1,1)
plot(t,X2)
subplot(3,1,2)
plot(f_FFT,Xk)
title 'X2 2 graphs'

FFT1 = fft(X1)
N_FFT = length(X1)/2; %length
f_FFT = (1:N_FFT) * Fs / (N_FFT); %sampling frequency
Xk = abs(FFT1(1:floor(N_FFT)));
Psd1 = Xk.^2;
figure(5)
subplot(3,1,1)
plot(t,X1)
subplot(3,1,2)
plot(f_FFT,Xk)
subplot(3,1,3)
plot(f_FFT,Psd1)
title 'X1 3 graphs'

FFT1 = fft(X2)
N_FFT = length(X2)/2; %length
f_FFT = (1:N_FFT) * Fs / (N_FFT); %sampling frequency
Xk = abs(FFT1(1:floor(N_FFT)));
Psd2 = Xk.^2;
figure(6)
subplot(3,1,1)
plot(t,X2)
subplot(3,1,2)
plot(f_FFT,Xk)
subplot(3,1,3)
plot(f_FFT,Psd2)
title 'X2 3 graphs'


D = abs(Psd1 - Psd2)
figure(9) %no.9
plot(D) %discriminant power of differences
title 'Discriminant power of differences'

a = 1;
b = high_pass(Fs);
X1filtered = filter(b,a,X1); %filter X1 with filter b
figure(10)
plot(t,X1filtered)
title 'High pass filter'

FFT1 = fft(X1filtered)
N_FFT = length(X1filtered)/2; %length
f_FFT = (1:N_FFT) * Fs / (N_FFT); %sampling frequency
Xk = abs(FFT1(1:floor(N_FFT)));
figure(11)
subplot(2,1,1)
plot(t,X1filtered)
title 'High pass filtered'
subplot(2,1,2)
plot(f_FFT,Psd1)
title 'FFT high pass filtered'

figure(12)
a = 1;
b = low_pass(Fs);
X1filtered = filter(b,a,X1); %filter X1 with filter b
plot(t,X1filtered)
title 'Low pass filter'

FFT1 = fft(X1filtered)
N_FFT = length(X1filtered)/2; %length
f_FFT = (1:N_FFT) * Fs / (N_FFT); %sampling frequency
Xk = abs(FFT1(1:floor(N_FFT)));
figure(13)
subplot(2,1,1)
plot(t,X1filtered)
title 'Low pass filtered'
subplot(2,1,2)
plot(f_FFT,Psd1)
title 'FFT low pass filtered'

figure(14)
a = 1;
b = band_pass(Fs);
X1filtered = filter(b,a,X1); %filter X1 with filter b
plot(t,X1filtered)
title 'Band pass filter'

