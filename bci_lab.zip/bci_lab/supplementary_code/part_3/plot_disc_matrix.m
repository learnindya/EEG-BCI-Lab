% Plot discriminant power matrix 6-40Hz by 16 electrodes
discmatrix = abs(eo_psd_2hz_mean(3:21,:) - % what should go here?
figure
imagesc([5 41], [1 16], discmatrix')
xlabel('Frequency bins [f-1,f+1) (Hz)')
ylabel('Channel number')
title('Discriminant power (feature matrix)')
clh = colorbar;
ylabel(clh, 'PSD (V^2/Hz)')
set(gca, 'XTick', % what shoudl go here ?
xlim([4 40])
set(gca, 'YTick', [1:16])