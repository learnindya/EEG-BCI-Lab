%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pre-filter data and calculate PSD for every epoch and every electrode. 
% The PSD should be resampled into 2Hz ?bins?
 
% Band pass 2-40 Hz (use the filter you designed earlier)
b_bp = band_pass(Fs);
 
% Iterate through every extracted epoch
for i = 1:N_epochs
    
    % Iterate through each electrode channel (Ei)
    for Ei = 1:16
        
        % Apply bandpass filter to eyes open
        eo_bp(:,:,Ei) = filter(b_bp, 1, eo{i}(:,Ei));
        
        %??? NOW FILTER EYES CLOSED ???% 
        ec_bp(:,:,Ei) = 
 
        % Calculate PSD for Ei using the Welch method
        [psd freqs] = pwelch(eo_bp(:,:,Ei), [], [], [], Fs);
        N_psd = length(psd) - 1;
        temp_psd = reshape(psd(1:N_psd), N_psd/(Fs / (2 * 2)), []);
        eo_psd_2hz(:,i,Ei) = mean(temp_psd,1);
 
        %??? NOW calculate PSD EYES CLOSED ???%
        ec_psd_2hz(:,i,Ei) = 
    end
end
