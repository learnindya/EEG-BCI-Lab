% Plot PSDs for Eyes Open (eo) and Eyes Closed (ec) 

% set up frequency axis
xf_temp = reshape(freqs(1:N_psd), N_psd/(Fs / (2 * 2)), []) - 1;
xf = xf_temp(1,:);

Ei = % Choose your electrode here!

% plot mean and std dev  
h = superbar(xf, [eo_psd_2hz_mean(:,Ei) ec_psd_2hz_mean(:,Ei)], 'E', [eo_psd_2hz_std(:,Ei)
ec_psd_2hz_std(:,Ei)]);

% Colour the groups and add legend (avoiding bug in superbar grouping)
Colours = [.8 .2 .2;
     .2 .8 .2];
for iBarSeries = 1:length(eo_psd_2hz_mean)
    set(h(iBarSeries, 1), 'FaceColor', Colours(1, :), 'EdgeColor', 'none');
    set(h(iBarSeries, 2), 'FaceColor', Colours(2, :), 'EdgeColor', 'none');
end
legend([h(1,1) h(1,2)], 'Eyes Open', 'Eyes Closed');

% Add labels and set axes limits
str_title = cell2mat(strcat({'PSD in 2Hz bins for '}, electrode_labels{Ei}));
title(str_title)
xlim([0,40])
set(gca, 'XTick', 1:2:39)
% ylim([0, 75])
ylabel('PSD (V^2/Hz)')
xlabel('Frequency bins [f-1, f+1)  (Hz)')