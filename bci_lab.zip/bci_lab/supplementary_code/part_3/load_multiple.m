%%
% Load each file and extract epochs, put in relevant structures
%

% Define the EEG file(s) of interest
fname = {'data_files/c30o30_s4_t1.bdf', 'data_files/c30o30_s4_t2.bdf'};

% Initialise epoch counter
N_epochs = 0;

for fi=1:length(fname)
    % Load the EEG file (fname{fi}). Note the semicolon to surpress echo 
    % of S and HDR to the command window. Don't worry about warnings 
    % concerning overflow detection or the lack of a status channel.
    %
    % For more info type:
    %
    % >> help sload
    %
    [S HDR] = sload(fname{fi});
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Extract triggers
    
    throw an error % insert your own code here to extract the triggers 
                   % (see previous part of the lab)
    

    % Discard 2 seconds of data before & after each cue
    discard = 2*Fs;

    % Extract each epoch of data and store in the relevant structure for 
    % each class
    % - ec: Eyes closed
    % - eo: Eyes open
    this_epochs = 0;
    Epoch_length = 24; % in seconds
    samples = Epoch_length*Fs;
    for i=1:N_trigs/2
        ec_extracted{i} = S(trig(2*i)+discard:trig(2*i+1)-discard,1:16);
        eo_extracted{i} = S(trig(2*i+1)+discard:trig(2*i+2)-discard,1:16);
        maxlen = min(length(ec_extracted{i}), length(eo_extracted{i}));
        N_loop = floor(maxlen / samples);
        for j = 1:N_loop
            N_epochs = N_epochs + 1;
            this_epochs = this_epochs + 1;
            ec{N_epochs} = ec_extracted{i}((j-1)*samples+1:j*samples,:);
            eo{N_epochs} = eo_extracted{i}((j-1)*samples+1:j*samples,:);
        end
    end
    disp(cell2mat(strcat({'Extracted '}, int2str(this_epochs), {', '},...
        int2str(Epoch_length), {' second epochs of each class from '})));
end
disp(cell2mat(strcat({'Extracted a total of '}, int2str(N_epochs),...
    {', '}, int2str(Epoch_length), {' second epochs of each class.'})));
