function plotFFT2(X_fft, Fs)
%
% plotFFT2(X_fft, Fs)
%
%   Helper function to plots the absolute FFT
%
%       X_fft = the Fast Fourier Transform of a signal, e.g. using fft()
%       Fs = sampling frequency of the original signal
%

% Number of positive FFT taps
N_fft = length(X_fft) / 2;

% Construct frequency axis (0 - 0.5Fs)
f_fft = (1:N_fft) * Fs / (2 * N_fft);

% Construct FFT weights 
Xk = abs(X_fft(1:floor(N_fft)));

Psd = Xk.^2;

plot(f_fft, Psd)

% % The following is commented in case this is used within a motage 
% % display, where you might not want to label every set of axes.
% % Uncomment to label axis within this function
% xlabel('Frequency (Hz)')
% % Example of setting the axis limits (zooming in/out)
% xlim([-Fs/40 Fs/2])
end
