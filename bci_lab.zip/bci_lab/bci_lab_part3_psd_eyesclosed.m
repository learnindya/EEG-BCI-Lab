clear all
close all
clc

%%
% Load each file and extract epochs, put in relevant structures
%

% Define the EEG file(s) of interest
fname = {'data_files/c30o30_s4_t1.bdf', 'data_files/c30o30_s4_t2.bdf'};

% Initialise epoch counter
N_epochs = 0;

for fi=1:length(fname)
    % Load the EEG file (fname{fi}). Note the semicolon to surpress echo 
    % of S and HDR to the command window. Don't worry about warnings 
    % concerning overflow detection or the lack of a status channel.
    %
    % For more info type:
    %
    % >> help sload
    %
    [S HDR] = sload(fname{fi});
    
    Fs=512;

% for i=1:17 
% figure 
% plot(S(:,i)) 
% end 

% Implements supplementary_code/part_2/extract_epochs.m 

% Find length of signal 
L = length(S); 
 
% Differentiate trigger channel 
delta_trig = S(2:L,17)-S(1:L-1,17);
  
% Look for rising edges 
trig = find(delta_trig>0); 
 
% Debounce if required 
% I.e. remove spurious short triggers, if any 
%      these can occur when using a manual switch-based trigger 
% e.g. look at the trigger channel in 'data_files/c30o30_s4_t1.bdf' 


T_debounce = 0.5; % (in seconds) - set as desired 
dt_trig = trig(2:end) - trig(1:end-1); 
delete_short_trigs = find(dt_trig < Fs*T_debounce) + 1; 
trig(delete_short_trigs) = []; 
  
% How many triggers were extracted in total, after debouncing? 
N_trigs = length(trig)-1; 
  
% Ensure we have an odd number of triggers (ignore final incomplete  
% epoch if not). 
% Trigger 1 = start of experiment 
% Triggers 2, 4, 6, 8... (2k) = eyes closed 
% Triggers 3, 5, 7, 9... (2k+1) = eyes open 
if mod(N_trigs, 2) == 0 
    N_trigs = N_trigs - 1; 
end     
  
disp(cell2mat(strcat({'Found '}, int2str(N_trigs), {' triggers.'}))); 
     
N_epochs = N_trigs; 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Extract triggers
    
    % throw an error % insert your own code here to extract the triggers 
                   % (see previous part of the lab)
    

    % Discard 2 seconds of data before & after each cue
    discard = 2*Fs;

    % Extract each epoch of data and store in the relevant structure for 
    % each class
    % - ec: Eyes closed
    % - eo: Eyes open
    this_epochs = 0;
    Epoch_length = 24; % in seconds
    samples = Epoch_length*Fs;
    for i=1:N_trigs/2
        ec_extracted{i} = S(trig(2*i)+discard:trig(2*i+1)-discard,1:16);
        eo_extracted{i} = S(trig(2*i+1)+discard:trig(2*i+2)-discard,1:16);
        maxlen = min(length(ec_extracted{i}), length(eo_extracted{i}));
        N_loop = floor(maxlen / samples);
        for j = 1:N_loop
            N_epochs = N_epochs + 1;
            this_epochs = this_epochs + 1;
            ec{N_epochs} = ec_extracted{i}((j-1)*samples+1:j*samples,:);
            eo{N_epochs} = eo_extracted{i}((j-1)*samples+1:j*samples,:);

        end
    end
    disp(cell2mat(strcat({'Extracted '}, int2str(this_epochs), {', '},...
        int2str(Epoch_length), {' second epochs of each class from '})));
end
disp(cell2mat(strcat({'Extracted a total of '}, int2str(N_epochs),...
    {', '}, int2str(Epoch_length), {' second epochs of each class.'})));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Plot FFT of raw data ec = eyes closed 
ec_fft = fft(ec{N_epochs}); 

% Implements supplementary_code/part_3/calc_psd.m 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Pre-filter data and calculate PSD for every epoch and every electrode.  
% The PSD should be resampled into 2Hz �bins� 

% Band pass 2-40 Hz (use the filter you designed earlier) 
b_bp = band_pass(Fs); 
  
% Iterate through every extracted epoch 
for i = 1:N_epochs 
     
    % Iterate through each electrode channel (Ei) 
    for Ei = 1:16 
         
        % Apply bandpass filter to eyes open 
        eo_bp(:,:,Ei) = filter(b_bp, {N_epochs}, eo{i}(:,Ei)); 
         
        %??? NOW FILTER EYES CLOSED ???%  
        ec_bp(:,:,Ei) = filter(b_bp, {N_epochs}, ec{i}(:,Ei)); 
  
        % Calculate PSD for Ei using the Welch method 
        [psd freqs] = pwelch(ec_bp(:,:,Ei), [], [], [], Fs); 
        N_psd = length(psd) - 1; 
        temp_psd = reshape(psd_ec(1:N_psd), N_psd/(Fs / (2 * 2)), []); 
        ec_psd_2hz(:,i,Ei) = mean(temp_psd,1); 
        
        % Calculate mean and standard deviation
        %eo_psd_2hz_mean(:,Ei) =  
        %eo_psd_2hz_std(:,Ei) =  
  
        %??? NOW calculate PSD EYES CLOSED ???% 
       
    end 
end

% plot(eo_psd_2hz,Fs)